import {
  MessageSquareWarning,
  CreditCard,
  Building2,
  UserPlus,
} from "lucide-react";

function QuickActions() {
  const actions = [
    {
      title: "Raise Complaint",
      icon: MessageSquareWarning,
      color: "purple",
    },
    {
      title: "Make Payment",
      icon: CreditCard,
      color: "green",
    },
    {
      title: "Book Facility",
      icon: Building2,
      color: "blue",
    },
    {
      title: "Invite Visitor",
      icon: UserPlus,
      color: "orange",
    },
  ];

  return (
    <div className="quick-actions">
      {actions.map((action) => {
        const Icon = action.icon;

        return (
          <button className="quick-action" key={action.title}>
            <div className={`quick-icon ${action.color}`}>
              <Icon size={21} />
            </div>

            <span>{action.title}</span>
          </button>
        );
      })}
    </div>
  );
}

export default QuickActions;