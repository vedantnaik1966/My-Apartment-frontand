function Residents() {
  return (
    <div className="placeholder-page">
      <h1>Residents</h1>
      <p>Residents management will be added here.</p>
    </div>
  );
}

export default Residents;