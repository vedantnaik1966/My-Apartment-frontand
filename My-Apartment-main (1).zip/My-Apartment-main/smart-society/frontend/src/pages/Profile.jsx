function Profile() {
  return (
    <div className="placeholder-page">
      <h1>My Home / Profile</h1>
      <p>Your apartment and profile information will appear here.</p>
    </div>
  );
}

export default Profile;