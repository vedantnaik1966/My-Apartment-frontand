function Payments() {
  return (
    <div className="placeholder-page">
      <h1>Payments</h1>
      <p>Payment management will be added here.</p>
    </div>
  );
}

export default Payments;