function Notices() {
  return (
    <div className="placeholder-page">
      <h1>Notices</h1>
      <p>Society notices will be added here.</p>
    </div>
  );
}

export default Notices;