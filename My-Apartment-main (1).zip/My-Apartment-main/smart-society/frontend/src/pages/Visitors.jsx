function Visitors() {
  return (
    <div className="placeholder-page">
      <h1>Visitors</h1>
      <p>Visitor management will be added here.</p>
    </div>
  );
}

export default Visitors;