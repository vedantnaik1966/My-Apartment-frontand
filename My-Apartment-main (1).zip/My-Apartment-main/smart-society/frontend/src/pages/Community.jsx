function Community() {
  return (
    <div className="placeholder-page">
      <h1>Community</h1>
      <p>Community will be added here.</p>
    </div>
  );
}

export default Community;