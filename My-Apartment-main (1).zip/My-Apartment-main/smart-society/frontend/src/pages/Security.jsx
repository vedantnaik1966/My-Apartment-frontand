function Security() {
  return (
    <div className="placeholder-page">
      <h1>Security</h1>
      <p>Security and safety information will be added here.</p>
    </div>
  );
}

export default Security;
