function Parking() {
  return (
    <div className="placeholder-page">
      <h1>Parking</h1>
      <p>Parking management and information will be added here.</p>
    </div>
  );
}

export default Parking;
