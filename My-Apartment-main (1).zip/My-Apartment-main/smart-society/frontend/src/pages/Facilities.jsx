function Facilities() {
  return (
    <div className="placeholder-page">
      <h1>Facilities</h1>
      <p>Facility booking will be added here.</p>
    </div>
  );
}

export default Facilities;